<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasColumn('users', 'last_login_at')) {
        Schema::table('users', function (Blueprint $table) {
        $table->timestamp('last_login_at')->nullable();
    });
}

        Schema::table('job_vacancies', function (Blueprint $table) {
            $table->integer('viewCount')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('last_login_at');
        });

        Schema::table('job_vacancies', function (Blueprint $table) {
            $table->dropColumn('viewCount');
        });
    }
};
